# Modernization Review

This note records the review findings that motivated the modernization merge.

- **Implicit parent-config inheritance** was present in `core_engine.md` Phase 2, where every continuation materialized from `prior_manifest.config_freeze`; that bypassed the documented child-manifest inheritance policy and risked leaking historical non-live config into new amendment, remediation, analysis, or drift branches.
- **Branch-ladder reuse logic was ordered incorrectly**: exact idempotent retries were evaluated after generic continuation checks, so a same-request terminal or still-sealed manifest could allocate a child manifest instead of reusing the persisted bundle or sealed context.
- **Assertion-driven validation was used for request and lineage compatibility** (`runtime_scope`, tenant/client/period/mode, continuation legality), which is a legacy crash-oriented pattern for externally sourced inputs; these checks needed to fail closed with typed reasons.
- **Contract drift existed across the spec surface**: `core_engine.md` called `ALLOCATE_MANIFEST`, while `continuation_set.config_inheritance_mode` was already required by narrative contracts but absent from `schemas/run_manifest.schema.json`.
- **Ordered gate persistence was expressed as record-by-record writes** even when the gate order was already materialized, which added transactional overhead and duplicated audit plumbing that belongs in a batched gate-persistence helper.
